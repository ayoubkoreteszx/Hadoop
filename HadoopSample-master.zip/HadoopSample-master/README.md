# Hadoop Single Node Cluster
 
Start Hadoop
> scripts/start-hadoop.sh


### Programs

Run Wordcount Program
> scripts/wordcount.sh

Run In Mapper Wordcount Program
> scripts/inmapper-wordcount.sh


# URL
1. http://localhost:9870/
1. http://localhost:8088/