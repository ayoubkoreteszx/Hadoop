hdfs namenode -format
start-all.sh